#include "Animation.h"
#include <stdio.h>
#include <iostream>

Animation::Animation() {
    init();
}

void Animation::init() {
    // Load sprite sheet here
    // spritesheet = al_load_bitmap("");
    // Load individual images here
    // Initialize all other variables here
    currentFrame = 0;
    loop = true;
    currentState = RUNNING;

    maxRunFrames = 8;
    maxJumpFrames = 10;
    maxShootFrames = 4;
    maxSlideFrames = 10;

    // Load all the sprites..
    // Running
    runImages[0] = al_load_bitmap("res/Run (1).png");
    if (!runImages[0]) printf("There's an error loading this shit!");
    runImages[1] = al_load_bitmap("res/Run (2).png");
    runImages[2] = al_load_bitmap("res/Run (3).png");
    runImages[3] = al_load_bitmap("res/Run (4).png");
    runImages[4] = al_load_bitmap("res/Run (5).png");
    runImages[5] = al_load_bitmap("res/Run (6).png");
    runImages[6] = al_load_bitmap("res/Run (7).png");
    runImages[7] = al_load_bitmap("res/Run (8).png");

    jumpImages[0] = al_load_bitmap("res/Jump (1).png");
    jumpImages[1] = al_load_bitmap("res/Jump (2).png");
    jumpImages[2] = al_load_bitmap("res/Jump (3).png");
    jumpImages[3] = al_load_bitmap("res/Jump (4).png");
    jumpImages[4] = al_load_bitmap("res/Jump (5).png");
    jumpImages[5] = al_load_bitmap("res/Jump (6).png");
    jumpImages[6] = al_load_bitmap("res/Jump (7).png");
    jumpImages[7] = al_load_bitmap("res/Jump (8).png");
    jumpImages[8] = al_load_bitmap("res/Jump (9).png");
    jumpImages[9] = al_load_bitmap("res/Jump (10).png");

    shootImages[0] = al_load_bitmap("res/Shoot (1).png");
    shootImages[1] = al_load_bitmap("res/Shoot (2).png");
    shootImages[2] = al_load_bitmap("res/Shoot (3).png");
    shootImages[3] = al_load_bitmap("res/Shoot (4).png");

    slideImages[0] = al_load_bitmap("res/Slide (1).png");
    slideImages[1] = al_load_bitmap("res/Slide (2).png");
    slideImages[2] = al_load_bitmap("res/Slide (3).png");
    slideImages[3] = al_load_bitmap("res/Slide (4).png");
    slideImages[4] = al_load_bitmap("res/Slide (5).png");
    slideImages[5] = al_load_bitmap("res/Slide (6).png");
    slideImages[6] = al_load_bitmap("res/Slide (7).png");
    slideImages[7] = al_load_bitmap("res/Slide (8).png");
    slideImages[8] = al_load_bitmap("res/Slide (9).png");
    slideImages[9] = al_load_bitmap("res/Slide (10).png");

    event_queue = al_create_event_queue();

    // To slow the robot down, set the value inside here to a higher number, or lesser to make the animation faster
    timer = al_create_timer(0.1);

    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_start_timer(timer);
}

void Animation::update() {

    switch (currentState) {
        case RUNNING:
            // If an event happened
            if (al_get_next_event(event_queue, &event)) {
                currentFrame++;
                if (currentFrame >= maxRunFrames) {
                    currentFrame = 0;
                }
            }
        break;
        case SLIDING:
            // If an event happened
            if (al_get_next_event(event_queue, &event)) {
                if (++currentFrame >= maxSlideFrames) {
                    currentFrame = 0;
                }
            }
        break;
        case SHOOTING:
            // If an event happened
            if (al_get_next_event(event_queue, &event)) {
                if (++currentFrame >= maxShootFrames) {
                    currentFrame = 0;
                }
            }
        break;
        case JUMPING:
            // If an event happened
            if (al_get_next_event(event_queue, &event)) {
                if (++currentFrame >= maxJumpFrames) {
                    currentFrame = 0;
                }
            }
        break;
    }

}

void Animation::handleInput(ALLEGRO_EVENT& event) {

    // Each key press will change animation state and reset the current animation

    // Space -- Jumping
    if (event.type == ALLEGRO_EVENT_KEY_DOWN && event.keyboard.keycode == ALLEGRO_KEY_SPACE) {
        currentState = JUMPING;
        currentFrame = 0;
        al_flush_event_queue(event_queue);
    }

    // Left
    if (event.type == ALLEGRO_EVENT_KEY_DOWN && event.keyboard.keycode == ALLEGRO_KEY_LEFT) {
        currentState = RUNNING;
        currentFrame = 0;
    }

    // Left Ctrl -- Shooting
    if (event.type == ALLEGRO_EVENT_KEY_DOWN && event.keyboard.keycode == ALLEGRO_KEY_LCTRL) {
        currentState = SHOOTING;
        currentFrame = 0;
    }

    // Down -- Sliding
    if (event.type == ALLEGRO_EVENT_KEY_DOWN && event.keyboard.keycode == ALLEGRO_KEY_DOWN) {
        currentState = SLIDING;
        currentFrame = 0;
    }
}

void Animation::render() {

    switch (currentState) {
        case RUNNING:
            al_draw_bitmap(runImages[currentFrame], 250, 100, 0);
        break;
        case JUMPING:
            al_draw_bitmap(jumpImages[currentFrame], 250, 100, 0);
        break;
        case SLIDING:
            al_draw_bitmap(slideImages[currentFrame], 250, 100, 0);
        break;
        case SHOOTING:
            al_draw_bitmap(shootImages[currentFrame], 250, 100, 0);
        break;
    }

}

void Animation::dispose() {
    // Disposing of the allocated sprites:::
    printf(":::Disposing of allocated objects:::");

    for (int i = 0; i < shootImages.size(); i++) {
        al_destroy_bitmap(shootImages[i]);
    }

    for (int i = 0; i < runImages.size(); i++) {
        al_destroy_bitmap(runImages[i]);
    }

    for (int i = 0; i < jumpImages.size(); i++) {
        al_destroy_bitmap(jumpImages[i]);
    }

    for (int i = 0; i < slideImages.size(); i++) {
        al_destroy_bitmap(slideImages[i]);
    }

    al_destroy_timer(timer);
    al_destroy_event_queue(event_queue);

    printf(":::Disposed of allocated objects, DONE:::");
}
