#pragma once
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>

#include <array>

enum AnimationState {
    RUNNING,
    JUMPING,
    SHOOTING,
    SLIDING
};

class Animation {
    public:
        Animation();
        void init();
        void update();
        void handleInput(ALLEGRO_EVENT& event);
        void render();
        void dispose();

    private:
        //ALLEGRO_BITMAP* spritesheet; // One big sprite sheet ( I prefer to use this though )
        std::array<ALLEGRO_BITMAP*, 8> runImages; // An array of individual images (This one's easier to implement
        std::array<ALLEGRO_BITMAP*, 10> jumpImages; // An array of individual images (This one's easier to implement
        std::array<ALLEGRO_BITMAP*, 4> shootImages; // An array of individual images (This one's easier to implement
        std::array<ALLEGRO_BITMAP*, 10> slideImages; // An array of individual images (This one's easier to implement
        int currentFrame; // The current frame
        int maxRunFrames;
        int maxJumpFrames;
        int maxShootFrames;
        int maxSlideFrames;
        AnimationState currentState;
        bool loop; // Whether to restart the animation when it gets to the end

        ALLEGRO_EVENT_QUEUE* event_queue;
        ALLEGRO_TIMER* timer;
        ALLEGRO_EVENT event;
};
