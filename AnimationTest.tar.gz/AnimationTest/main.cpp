#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>

#include "Animation.h"
#include <iostream>

int main() {

    assert(al_init());

    assert(al_init_image_addon());

    auto display = al_create_display(1024, 768);
    auto timer = al_create_timer(1.0/60);
    auto event_queue = al_create_event_queue();

    al_install_keyboard();

    al_register_event_source(event_queue, al_get_display_event_source(display));
    al_register_event_source(event_queue, al_get_timer_event_source(timer));
    al_register_event_source(event_queue, al_get_keyboard_event_source());

    ALLEGRO_EVENT event;
    bool running = true;
    bool redraw = true;

    Animation animation;

    al_start_timer(timer);
    while (running) {
        al_wait_for_event(event_queue, &event);
        switch (event.type) {
            case ALLEGRO_EVENT_DISPLAY_CLOSE:
                running = false;
                break;
            case ALLEGRO_EVENT_TIMER:
                animation.update();
                animation.handleInput(event);
                redraw = true;
                break;
            case ALLEGRO_EVENT_KEY_DOWN:
            case ALLEGRO_EVENT_KEY_UP:
                animation.handleInput(event);
                break;
        }

        if (redraw && al_is_event_queue_empty(event_queue)) {
            redraw = false;
            al_clear_to_color(al_map_rgb_f(0, 0, 0));
            animation.render();
            al_flip_display();
        }
    }

    animation.dispose();

    al_destroy_display(display);
    al_destroy_event_queue(event_queue);
    al_destroy_timer(timer);

    return 0;
}
